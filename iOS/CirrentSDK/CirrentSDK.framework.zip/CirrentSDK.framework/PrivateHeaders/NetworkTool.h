//
//  NetworkTool.h
//  CirrentSDK
//
//  Created by P on 2/8/17.
//  Copyright © 2017 Marco. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NetworkTool : NSObject

+(NSString*) getWifiAddress;

@end
