//
//  CirrentSDK.h
//  CirrentSDK
//
//  Created by PSIHPOK on 3/17/17.
//  Copyright © 2017 PSIHPOK. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CirrentSDK.
FOUNDATION_EXPORT double CirrentSDKVersionNumber;

//! Project version string for CirrentSDK.
FOUNDATION_EXPORT const unsigned char CirrentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CirrentSDK/PublicHeader.h>
